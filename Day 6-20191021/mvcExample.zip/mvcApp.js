//MVC is an architecture for clean seperation of User interface, processing and data. The User interface is called as View, the processing is done by a Code called Controller. The data that U want to send to the View is called as Model.

//When a page is rendered from the server to the client, some content or data should also be sent to the client App. browsers dont understand server side variables. U need a processor for accessing the server side variables and display that in the browser. This is done by View-engines.  
var express = require("express");
var parser = require("body-parser");
var join = require("path").join;
var app = express();

//Viewer for ur docucment...
app.engine("html", require("ejs").renderFile);
app.set("view engine", "jade");
app.use(parser.urlencoded({"extended": false}));

var root = __dirname;
app.get("/", (req, res)=>{
	res.sendFile(root + "/UserInput.html")
});


//U cannot render an HTML Output file as a return of a Response. WE use ViewEngines, a View Engine is a program that processes the HTML Content from the server and injects data from the server and renders the requested pages along with the data inserted at appropriate locations into the Browser. 
//Popular View engine of Express is Jade.

app.post("/process", (req, res)=>{
	console.log(req.body);
	var data = req.body;
	var info = "Thanks for the info. We will come send other details to Mr." + data.name + " thro his email address: " + data.email;
	//sendMsg(res, data)
	res.render("Thanks", {msg : info, test:"Apple123"});
});

app.listen(1234, ()=>{
	console.log("App is running at 1234");
})

function sendMsg(res, data){
	var content ="<h1>Thanks for registering with us</h1>";
	content += "<hr/>";
	content += "<p>We will post the acknowlegement to Mr." + data.name + "</p>";
	res.send(content);
} 